<?php
define("DBHOST", "localhost");
define("DBNAME", "bacigalupi_689352");
define("DBUSER", "root");
define("DBPASS", "");
